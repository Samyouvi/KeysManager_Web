<?php
  $errors = '';
  $confirmation = '';
  $selected_onglet = 1;
  $object;

	// Events capture
  if(isset($_GET['onglet'])) {
  	$tmp = (int)htmlspecialchars($_GET['onglet']);
  	if($tmp > 0 && $tmp < 6)
  		$selected_onglet = $tmp;
  }

  // Displays functions
  function showForm() {
    global $object;
    //echo $object->getId();
    if($object != null) {
      $object_name = str_replace('VO', '', get_class($object));
      echo '<fieldset>'."\n";
      echo '<legend>'.$object_name.' (id: '.$object->getId().')</legend>';
      echo '<form method="POST">'."\n";
      foreach(((array) $object) as $field => $value) {
        $field = trim($field, "* \t\n\r\0\x0B"); // remove characters (" *") added by the cast
        $locker = '';
        // Specialization
        if($field == 'creationDate' || $field == 'enssatPrimaryKey' || $field == 'id_'.strtolower(str_replace('VO', '', get_class($object)))) {
          $locker = 'disabled';
        }
        if($object_name == 'User' && $field == 'status') {
          echo '<label for="'.$field.'">'.$field.': </label><select id="'.$field.'" name="'.$field.'" '.$locker.'/>'."\n";
          foreach ($object->getStatusCollection() as $key => $status) {
            if($status == $value)
              echo '<option value="'.$key.'" selected>'.$status.'</option>'."\n";
            else
              echo '<option value="'.$key.'">'.$status.'</option>'."\n";
          }
          echo '</select><br/>'."\n";
        } else if($object_name == 'Keychain' && $field == 'status') {
          echo '<label for="'.$field.'">'.$field.': </label><select id="'.$field.'" name="'.$field.'" '.$locker.'/>'."\n";
          foreach ($object->getStatusCollection() as $status) {
            if($status == $value)
              echo '<option value="'.$status.'" selected>'.$status.'</option>'."\n";
            else
              echo '<option value="'.$status.'">'.$status.'</option>'."\n";
          }
          echo '</select><br/>'."\n";
        } else if(stripos($field, 'date')!==false) {
          $value = substr_replace($value, '-', 6, 0);
          $value = substr_replace($value, '-', 4, 0);
          echo '<label for="'.$field.'">'.$field.': </label><input type="date" id="'.$field.'" name="'.$field.'" value="'.$value.'" '.$locker.'/><br/>'."\n";
        } else {
          echo '<label for="'.$field.'">'.$field.': </label><input type="text" id="'.$field.'" name="'.$field.'" value="'.$value.'" '.$locker.'/><br/>'."\n";
        }
      }
      echo '<input type="submit" name="btn_edit" value="Modifier"/>'."\n";
      echo '</form>'."\n";
      showErrors();
      showConfirmation();
      echo '</fieldset>'."\n";
    } else {
      $errors = 'Le type de donnée demandé est inconnu.';
    }
  }

  function getForm1() {
  echo <<<CODE
<form method="POST">
  <div class="align_left">
    <input list="users" type="text" id="user_choice" placeholder="utilisateur">
    <datalist id="users">
      <option value="user1">
      <option value="user2">
      <option value="user3">
      <option value="user4">
    </datalist>
    <input name="submit_add_user" class="lien" type="submit" value="créer nouvel utilisateur"><br/>
  <input list="keyrings" type="text" id="keyring_choice" placeholder="trousseau">
  <datalist id="keyrings">
    <option value="keyring1">
    <option value="keyring2">
    <option value="keyring3">
    <option value="keyring4">
  </datalist>
  <input name="submit_add_keyring" class="lien" type="submit" value="créer nouveau trousseau"><br/>
  </div>
  <ul class="fist_legend">
    <li>Dates du prêt:</li>
    <li>début&nbsp;<input type="date" id="date_debut_pret" name="date_debut_pret"/></li>
    <li>fin&nbsp;&nbsp;&nbsp;<input type="date" id="date_fin_pret" name="date_fin_pret"/></li>
  </ul>
  <input name="submit_valider" type="submit" value="Valider">
</form>
CODE;
    }

  function getForm2() {
    global $_userDAO, $object;
    if(!isset($_POST['submit_valider_onglet2'])){
      echo <<<CODE
      <form method="POST">
      <input type="text" name="username" placeholder="username"><br/>
      <input name="submit_valider_onglet2" type="submit" value="Valider">
      </form>
CODE;

    }else{
      if($_userDAO->getUserIdWithUsername($_POST['username']) == -1){
        echo <<<CODE
        <form method="POST">
        <input type="text" name="username" value="{$_POST['username']}" readonly><br/>
        <input type="text" name="name" placeholder="name"><br/>
        <input type="text" name="surname" placeholder="surname"><br/>
        <select name="status">
              <option value="Student">Student</option>
              <option value="Staff">Staff</option>
              <option value="Outsider">Outsider</option>
        </select><br/>
        <input type="number" name="phone" placeholder="phone"><br/>
        <input type="email" name="email" placeholder="email"><br/>
        <input name="submit_valider_user" type="submit" value="Valider">
        </form>
CODE;
        }else{
          $id_object = $_userDAO->getUserIdWithUsername($_POST['username']);
          $object = $_userDAO->getUserById($id_object);
          showForm();
        }
    }
    if(isset($_POST['submit_valider_user'])){
    $users = $_userDAO->getUsers();
    $user = new UserVO();
    $user->setId(((double) $users[count($users)-1]->getId())+1);
    $user->setUrlidentifier(($users[count($users)-1]->getUrlidentifier())+1);
    $user->setUsername($_POST['username']);
    $user->setName($_POST['name']);
    $user->setSurname($_POST['surname']);
    $user->setStatus($_POST['status']);
    $user->setPhone($_POST['phone']);
    $user->setEmail($_POST['email']);
    $_userDAO->setUser($user);
  }
}

  function getForm3() {
    echo <<<CODE
<form method="POST">
  <div class="align_left">
    <input type="text" id="keyring" placeholder="keyring name"><br/>
    <input list="keys" type="text" id="key_choice" placeholder="key">
    <datalist id="keys">
      <option value="key1">
      <option value="key2">
      <option value="key3">
      <option value="key4">
    </datalist>
    <input name="submit_add_key" class="lien" type="submit" value="ajouter la clé">
  </div>
  <div id="added_keys_block"></div><br/>
  <input name="submit_valider" type="submit" value="Valider">
</form>
CODE;
  }

  function getForm4() {
        echo <<<CODE
<form method="POST">
  <div class="align_left">
    <input type="text" id="key" placeholder="key name"><br/>
    <input list="doors" type="text" id="key_choice" placeholder="door">
    <datalist id="doors">
      <option value="door1">
      <option value="door2">
      <option value="door3">
      <option value="door4">
    </datalist>
    <input name="submit_add_door" class="lien" type="submit" value="ajouter une porte">
  </div>
  <div id="added_doors_block"></div><br/>
  <input name="submit_valider" type="submit" value="Valider">
</form>
CODE;
  }

  function getForm5() {
  global $_doorDAO, $object, $_roomDAO, $_lockDAO;
    if(!isset($_POST['submit_valider_onglet4'])){
      echo <<<CODE
      <form method="POST">
      <input type="text" name="name" placeholder="door name"><br/>
      <input name="submit_valider_onglet4" type="submit" value="Valider">
      </form>
CODE;
      }else{
        if($_doorDAO->getDoorIdWithName($_POST['name']) == -1){
          echo <<<CODE
          <form method="POST">
CODE;
        echo '<select name="room">';
        $rooms = $_roomDAO->getRooms();
        foreach($rooms as $room){
          echo '<option value="'.$room->getName().'">'.$room->getName().'</option>';
        }
        echo '</select></br>';
        echo '<select name="lock">';
        $locks = $_lockDAO->getLocks();
        foreach($locks as $lock){
          echo '<option value="'.$lock->getId().'">'.$lock->getId().'</option>';
        }
        echo '</select></br>';
echo <<<CODE
            <input type="text" name="name" value="{$_POST['name']}" readonly><br/>
            <input name="submit_valider_door" type="submit" value="Valider">
          </form>
CODE;
        }else{
          $id_object = $_doorDAO->getDoorIdWithName($_POST['name']);
          $object = $_doorDAO->getDoorById($id_object);
          showForm();
        }
      }
        if(isset($_POST['submit_valider_door'])){
        $doors = $_doorDAO->getDoors();
        $door = new DoorVO();
        $door->setId(($doors[count($doors)-1]->getId())+1);
        $door->setIdRoom($_roomDAO->getRoomIdWithName($_POST['room']));
        $door->setIdLock($_POST['lock']);
        $door->setLengthLock($_lockDAO->getLengthById($_POST['lock']));
        $door->setName($_POST['name']);
        $_doorDAO->setDoor($door);
      }
  }

  function isActive($index) {
    global $selected_onglet;
    if($selected_onglet==$index) echo ' onglet_actif';
  }

  function showContent($index) {
    global $selected_onglet;
    if($selected_onglet==$index) echo ' contenu_onglet_actif';
  }

  function showErrors() {
    global $errors;
    if(strlen($errors)>0) {
      echo '<div class="error">'.$errors.'</div>';
    }
  }

  function showConfirmation() {
    global $confirmation;
    echo $confirmation."\n";
  }

?>
