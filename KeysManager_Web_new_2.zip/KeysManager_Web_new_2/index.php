<?php
  session_start();
  require_once('controllers/imports.php');
  include('controllers/controller.php');
?>
